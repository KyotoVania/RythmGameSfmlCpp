/*
** EPITECH PROJECT, 2023
** Yiang
** File description:
** Beatmap.hpp
*/
#ifndef BEATMAP_HPP_
	#define BEATMAP_HPP_

class Beatmap {
	public:
		Beatmap();
		~Beatmap();
	protected:
	private:
};

#endif /*BEATMAP_HPP_*/