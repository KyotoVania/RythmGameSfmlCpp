/*
** EPITECH PROJECT, 2023
** Yiang
** File description:
** ButtonConfig.cpp
*/

#include "GraphicElement/Button.hpp"


