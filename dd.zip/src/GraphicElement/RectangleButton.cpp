/*
** EPITECH PROJECT, 2023
** Yiang
** File description:
** RectangleButton.cpp
*/

#include "GraphicElement/RectangleButton.hpp"
