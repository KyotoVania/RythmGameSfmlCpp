/*
** EPITECH PROJECT, 2023
** Yiang
** File description:
** Beatmap.cpp
*/

#include "Beatmap/Beatmap.hpp"

Beatmap::Beatmap()
{
}

Beatmap::~Beatmap()
{
}