/*
** EPITECH PROJECT, 2023
** Yiang
** File description:
** PlayerIngame.cpp
*/

#include "Player/PlayerIngame.hpp"

PlayerIngame::PlayerIngame()
{
}

PlayerIngame::~PlayerIngame()
{
}